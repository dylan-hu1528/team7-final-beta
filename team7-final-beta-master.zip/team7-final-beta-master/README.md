# team7-final-beta

Description:

This peer evaluation ruby on rails application allows a user to 
sign up on the main page and access the class page that the
user is assigned to. 

Each user that is signed up for the peer evaluation tool can be assigned 
to a class and a team by the administrator. This administrator can 
create classes and teams within those classes. 

Once in a class, a normal user(student) can see their class and team. 
They can then create evaluations for the team.

Administrators have additional privileges including adding/removing classes
and teams as well as viewing peer feedback for students.

------------------------------------
Notice:
The evaluations need to formatted in a specific manner. Ideally, the 
user must should differentiate the projects by specifying the project
and name of the the peer he/she is evaluating in the evaluation name section
(i.e Project 2 - John Doe). Evaluations should be done for each team member.
The score indicates the score they gave the peer. Comments tell additional 
information.

------------------------------------
Instructions:

1.To create a class you need to be logged in as an admin user which you can create throguh the sign up page
2.Once logged in you can type the name of a class and hit the create button to make it
3.You then edit the class to add student users to it (student users need to be made i.e. signup and not be an admin)
4.Once users are added to the class you can view the class to create a team
5.Edit the team to add a user from the class to the team
6.Once a user has been added to the team you can go back to the view of all teams in the class and view the team.
7.From the team view as an admin you can see the users in the team and any evaluations made/make an eval. As a student you can see the team memebers and make an eval

In a student view you will be able to see the class the student is assigned to and the team the student is assigned to in the class.
Once in the team view the student can create an evaluation for the team and only see their evaluations of the team

IMPORTANT: To differentiate the projects the users should have the project name as their title for the peer evaluation and scores should follow the format name:score for the name of a group member and their score. Comments are up the the student


------------------------------------
Running the program:
1. Use the command terminal to go into the 'PeerEvaluationTool' 
directory.

2. Run 'bundle install' to install all needed gems.

3. Run 'rake db:migrate' to create the database. 

4. Run 'rails s' or 'rails server' to start the server(and follow instructions that console provides if this does not succeed).

5. Use a web browser to go to the application. (Default: localhost:3000 
in the url)

------------------------------------
References:
https://guides.rubyonrails.org/getting_started.html
https://www.bootstrapcdn.com/



