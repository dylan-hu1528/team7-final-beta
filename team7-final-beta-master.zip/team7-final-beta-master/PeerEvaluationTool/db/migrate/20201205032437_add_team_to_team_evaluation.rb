class AddTeamToTeamEvaluation < ActiveRecord::Migration[6.0]
  def change
    add_reference :team_evaluations, :team, null: false, foreign_key: true
  end
end
