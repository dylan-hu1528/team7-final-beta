class CreateTeamEvaluations < ActiveRecord::Migration[6.0]
  def change
    create_table :team_evaluations do |t|
      t.string :name
      t.textarea :score
      t.textarea :comment

      t.timestamps
    end
  end
end
