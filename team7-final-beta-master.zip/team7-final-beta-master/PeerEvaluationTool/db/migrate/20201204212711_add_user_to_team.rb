class AddUserToTeam < ActiveRecord::Migration[6.0]
  def change
    add_column :teams, :user, :integer
  end
end
