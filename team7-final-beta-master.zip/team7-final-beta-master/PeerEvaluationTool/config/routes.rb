Rails.application.routes.draw do
  resources :passwords, controller: "clearance/passwords", only: [:create, :new]
  resource :session, controller: "clearance/sessions", only: [:create]

  #get request for admin creation
  post '/users' => 'users#create'

  resources :users, controller: "clearance/users", only: [:create] do
    resource :password,
      controller: "clearance/passwords",
      only: [:edit, :update]
  end

  get "/sign_in" => "clearance/sessions#new", as: "sign_in"
  delete "/sign_out" => "clearance/sessions#destroy", as: "sign_out"
  get "/sign_up" => "clearance/users#new", as: "sign_up"
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
  
  resources :classes do
    resources :teams
  end

  resources :team_evaluations
  #root index goes to home controller and index action 
  root 'home#index'

  get 'about' => 'pages#about'
  get 'home' => 'home#index'
  get 'remove_class_path', to: 'classes#remove'
  get 'remove_team_path', to: 'teams#remove'
end
