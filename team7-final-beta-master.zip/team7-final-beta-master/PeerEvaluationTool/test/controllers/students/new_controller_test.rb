require 'test_helper'

class Students::NewControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get students_new_index_url
    assert_response :success
  end

end
