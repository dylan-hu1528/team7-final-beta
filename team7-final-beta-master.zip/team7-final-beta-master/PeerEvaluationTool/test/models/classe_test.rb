require 'test_helper'

class ClasseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
