module StartupHelper
end
