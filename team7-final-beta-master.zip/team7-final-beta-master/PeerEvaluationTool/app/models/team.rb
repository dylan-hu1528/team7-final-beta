class Team < ApplicationRecord
  #Validates title of team. Team has many user and evals
  validates :title, presence: true,length: {minimum: 1}
  belongs_to :classe
  has_many :users
  has_many :team_evaluations, dependent: :destroy
end
