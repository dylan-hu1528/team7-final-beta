class TeamEvaluation < ApplicationRecord
    #An eval belongs to a team and a user
    belongs_to :team
    belongs_to :user
end
