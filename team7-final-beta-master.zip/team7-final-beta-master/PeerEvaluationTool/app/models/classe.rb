class Classe < ApplicationRecord
    #Validate name presence and it has many teams and users
    validates :name, presence: true, length: {minimum: 1}
    has_many :teams, dependent: :destroy
    has_many :users
end
