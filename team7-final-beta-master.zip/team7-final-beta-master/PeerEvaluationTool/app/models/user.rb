class User < ApplicationRecord
  include Clearance::User
  #A user belongs to a class and team. User is validated by email and has many team evaluations
  belongs_to :classe, optional: true 
  belongs_to :team, optional: true
  has_many :team_evaluations, dependent: :destroy
  validates :email, format: { with: URI::MailTo::EMAIL_REGEXP}
  #validates_uniqueness_of :username
  #validates_uniqueness_of :password
end
