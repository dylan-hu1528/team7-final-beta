class TeamsController < ApplicationController
  before_action :adminPermissons, except: [:index, :show]
  
  #Check for admins permissions
  def adminPermissons
    @admin = current_user.admin
    if !@admin 
      redirect_to :controller => 'classes', :action => 'index'
    end 
  end

  #Displays homepage for teams
  def index
    @user = current_user
    @admin = current_user.admin
    @classe = Classe.find(params[:class_id])
    @teams = @classe.teams
  end

  #Creates a team
  def create
    @classe = Classe.find(params[:class_id])
    @team = @classe.teams.create(team_params)
    if @team.title != ""
      redirect_to class_path(@classe), notice: "Added Team"
    else
      redirect_to class_path(@classe), alert: "Team could not be Created"
    end
  end

  #Deletes a Team
  def destroy
    @classe = Classe.find(params[:class_id])
    @team = @classe.teams.find(params[:id])
    @team.users.clear
    @team.destroy
    redirect_to class_path(@classe)
  end
    
  #Edits a team
  def edit
    @classe = Classe.find(params[:class_id])
    @team = @classe.teams.find(params[:id])
  end

  #Updates a Team(adding/removing users)
  def update
    isInClass = false
    @classe = Classe.find(params[:class_id])
    @teams = Team.find(params[:id])
    @teamHash = (params[:team])
    @user = @teamHash['user']
    @allClassesTeams = @classe.teams 
    inATeam = false

    #Checks to make sure the user is in the class
    if @user != ""
      @classe.users.all.each do |u|
        if u.id.to_i == @user.to_i
          isInClass = true
        end
      end
      #Makes sure the user isn't in another team
      if isInClass
        @allClassesTeams.each do |t|
          t.users.each do |u|
            if u.id.to_i == @user.to_i
              inATeam = true
            end
          end
        end
        #Add user
        unless inATeam
          @teams.update(team_params)
          @teams.users << User.find(@teamHash['user'])
          redirect_to edit_class_team_path, notice: 'User Added!'
        else
          redirect_to edit_class_team_path, alert: 'User is already in a team'
        end
      else
        @teams.update(team_params)
        redirect_to edit_class_team_path, alert: 'User is not in this class'
      end
    else
      @teams.update(team_params)
      redirect_to edit_class_team_path, notice: 'Team name changed!'
    end
  end

  #shows a team
  def show
    @classe = Classe.find(params[:class_id])
    @team = @classe.teams.find(params[:id])
  end

  #Removes all users from a team
  def remove
    @user = User.all.find(params[:format])
    @team= @user.team
    @team.users.delete(@user)
    @classe = @user.classe
    redirect_to edit_class_team_path(@classe,@team), notice: 'User Removed'
  end
     
  #Defines params for a team
  private
    def team_params
      params.require(:team).permit(:title)
    end
  end

