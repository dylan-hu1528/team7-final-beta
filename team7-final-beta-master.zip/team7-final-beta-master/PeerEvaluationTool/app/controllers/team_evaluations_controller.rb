class TeamEvaluationsController < ApplicationController
    #Shows Evaluations Page and displays users
    def show
        @team = Team.find(params[:id])
        @user = current_user
    end

    #Directs User to create a new Evaluation
    def new
        @team = Team.find(params[:format])
        @user = current_user
    end

    #Creates a New Evaluation
    def create
        @eval = TeamEvaluation.new(evaluation_params)
        @eval.save
        if @eval.save
            redirect_to team_evaluation_path(@eval.team_id), notice: 'Success!'
        else
            redirect_to team_evaluation_path(@eval.team_id)
        end
    end

    #Directs user to a page to edit evaluations
    def edit
        @eval = TeamEvaluation.find(params[:id])
        @team = @eval.team
    end

    #Updates database with changes from edit
    def update
        @eval = TeamEvaluation.find(params[:id])
        @team = @eval.team
        @eval.update(evaluation_params)
        if @eval.update(evaluation_params)
            redirect_to team_evaluation_path(@eval.team_id), notice: 'Evaluation Updated!'
        else
            redirect_to team_evaluation_path(@eval.team_id), alert: 'Evaluation did not save'
        end
    end

    #Destroy and removes the evaluation
    def destroy
        @eval = TeamEvaluation.find(params[:id])
        @team = @eval.team
        @eval.destroy
        redirect_to team_evaluation_path(@team), notice: 'Delete Successful!'
    end




    private
    def evaluation_params
        params.require(:team_evaluation).permit(:name,:score,:comment,:team_id,:user_id)
    end




end
