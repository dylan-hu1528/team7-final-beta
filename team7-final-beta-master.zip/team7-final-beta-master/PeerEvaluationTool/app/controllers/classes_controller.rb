class ClassesController < ApplicationController
    before_action :require_login
    before_action :adminPermissons, except: [:index, :show]

    #Check for admins permissions
    def adminPermissons
        @admin = current_user.admin
        if !@admin 
            redirect_to classes_path
        end 
    end
    
    #Goes to the homepage for the application
    def index
        @user = current_user
        @admin = current_user.admin
        @classe = Classe.new
        @classes = Classe.all
    end
    
    #Create a class and display a message
    def create
        @classe = Classe.new(classe_params)
        @classe.save
        if @classe.save
            redirect_to classes_path, notice: 'Class Created!'
        else
            @classes = Classe.all
            redirect_to classes_path, alert: 'Class Could Not Be Created!'
        end
    end

    #Shows a Specific class
    def show
        @team = Team.new
        @admin = current_user.admin
        @classe = Classe.find(params[:id])
    end

    #Edits a specific class
    def edit
        @classe = Classe.find(params[:id])
        @users = User.all
    end

    #Update a class
    def update
        #Find the class and get the user
        @classe = Classe.find(params[:id])
        @classeHash = params[:classe]
        @user = @classeHash['user']
        @All_Classes = Classe.all
        inAClass = false
        #Make sure that the user exits and in the class and not an admin
        if @user != "" && @user.to_i <= User.all.last.id && !((User.find(@user)).admin)
            @classe.update(classe_params)
            @All_Classes.each do |c|
                #Checks to make sure the user is not already in a class
                c.users.each do |u|
                    if u.id.to_i == @user.to_i
                        inAClass = true
                    end
                end
            end
            #Adds user to a class
            unless inAClass
                @classe.users << User.find(@classeHash['user'])
                redirect_to edit_class_path, notice: 'User Added!'
            else
                redirect_to edit_class_path, alert: 'User is already in a class'
            end
        else
            if @user == ""
                @classe.update(classe_params)
                redirect_to edit_class_path, notice: 'Name Changed'
            else
                redirect_to edit_class_path, alert: 'This User cannot be Added'
            end
        end
    end

    #Destroy a Class
    def destroy
        @classe = Classe.find(params[:id])
        @teams = @classe.teams
        @teams.each do |t|
            t.users.clear
        end
        @classe.destroy
        redirect_to classes_path, notice: 'Delete Successful!'
    end

    #removes user from the class and any team
    def remove
        @user = User.all.find(params[:format])
        @classe = @user.classe
        if @user.team != nil
            @team = @user.team
            @team.users.delete(@user)
        end
        @classe.users.delete(@user)
        redirect_to edit_class_path(@classe), notice: 'Remove Successful!'
    end

    #Set params for classes
    private
        def classe_params
            params.require(:classe).permit(:name)
        end
    end
