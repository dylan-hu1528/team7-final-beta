class PagesController < ApplicationController
    #This will direct to a user info page
    def about
        @className = 'CSE 3901'
        @content = 'content'
        @user = current_user
    end 
end
