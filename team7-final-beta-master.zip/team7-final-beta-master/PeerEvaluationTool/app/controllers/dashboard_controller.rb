class DashboardController < ApplicationController
    def show
        @user = current_user.admin
    end 
end
