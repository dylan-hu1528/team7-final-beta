class Students::NewController < ApplicationController
  def index
  end
end
