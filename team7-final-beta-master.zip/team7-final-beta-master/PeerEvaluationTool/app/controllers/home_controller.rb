class HomeController < ApplicationController
    before_action :require_login
    #Just redirects home to the class path
    def index
        redirect_to classes_path
    end
end
